#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import time 
import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
import faiss
from memory.doc import DocumentProcessor
from utils import get_keys
from utils import logger

# 假设层级定义和各层权重
LAYER_WEIGHTS = {
    "profile": 1.5,
    "scene_init": 1.3,
    "scene_objective": 1.4,
    "conversation": 1.0,
    "summary_conversation": 1.2, # Summaries might be slightly more important than raw convo
    "summary_scene_init": 1.1,
    "summary_scene_objective": 1.3,
    "archived_conversation": 0.2, # Low weight for archived items
    "archived_scene_init": 0.1,
    "archived_scene_objective": 0.1,
}
LAYER_WEIGHT = 0.5
TEXT_WEIGHT = 0.5

# 定义MemoryChunk
class MemoryChunk:
    def __init__(self, chunk_id, text, layer, metadata=None, timestamp=None, scene_id=None): # Added scene_id
        self.id = chunk_id
        self.text = text
        self.layer = layer
        self.metadata = metadata or {}
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.embedding = None
        self.scene_id = scene_id # Store scene_id

    def __repr__(self):
        return f"MemoryChunk(id={self.id}, layer={self.layer}, scene_id={self.scene_id}, text={self.text})"

#   MemoryStorage：存储和索引构建
#   负责将每个记忆单元以 MemoryChunk 形式存储
#   同时维护两个索引：文本索引用于 BM25，向量索引用于语义匹配（faiss）。
#   每个记忆单元包含文本、层级信息、元数据及embedding向量。层级信息（profile, scene_init, scene_objective, conversation）可用于后续检索时的权重调整。
class MemoryStorage:
    def __init__(self, embed_model_name="all-MiniLM-L6-v2"):
        
        self.chunks = {}  # id -> MemoryChunk
        self.next_id = 0
        
        self.documents_for_bm25 = []  # List of tokenized texts for BM25
        self.chunk_ids_in_bm25_faiss_order = [] # Stores chunk_ids in the same order as documents_for_bm25 and FAISS vectors

        self.embed_model = SentenceTransformer(embed_model_name)
        self.dimension = self.embed_model.get_sentence_embedding_dimension()
        self.faiss_index = faiss.IndexFlatL2(self.dimension)
        self.bm25 = None
        self.layers = get_keys(LAYER_WEIGHTS)
        self.layer_embeddings = {}
        self._preload_layer_embeddings()
        # OPTIMIZATION: Store dialogue IDs ordered per scene
        # { scene_id: [dialogue_chunk_id_A, dialogue_chunk_id_C, ...], ... }
        # self.scene_dialogues_ordered_ids = defaultdict(list)
    def _preload_layer_embeddings(self):
        
        logger.debug("Preloading layer embeddings...")
        for layer_name in self.layers:
            # Embed the layer name (e.g., "profile layer", "conversation layer")
            # Adding " layer" can sometimes help the model understand context
            self.layer_embeddings[layer_name] = self.embed_model.encode(f"{layer_name} layer").astype('float32')
        logger.debug("Layer embeddings preloaded.")

    def add_chunk(self, text, layer, metadata=None, scene_id=None, language="en"):
        chunk_id = self.next_id
        # Ensure robust tokenization for Chinese, e.g., using jieba
        # For BM25, it's better to tokenize text properly.
        # Example: `tokenized_text = list(jieba.cut(text))` if using jieba
        # if language == "zh":
        #     tokenized_text = list(jieba.cut(text))
        # else:
        #     tokenized_text = text.split() # Replace with proper tokenizer for your language
        chunk = MemoryChunk(chunk_id, text, layer, metadata, scene_id=scene_id)
        self.chunks[chunk_id] = chunk
        self.next_id += 1

        # Add to BM25 tracking lists
        tokenized_text = DocumentProcessor().tokenize_text(layer+":"+text)
        self.documents_for_bm25.append(tokenized_text)
        self.chunk_ids_in_bm25_faiss_order.append(chunk_id)

        # Calculate and add embedding to FAISS
        layer_embedding = self.layer_embeddings.get(chunk.layer)
        if layer_embedding is None:
            # Handle cases where chunk.layer is not in unique_layers (e.g., embed it on the fly or log a warning)
            logger.warning(f"Warning: Unexpected layer '{chunk.layer}'. Embedding on the fly.")
            layer_embedding = self.embed_model.encode(f"{chunk.layer} layer").astype('float32')

        embedding = self.embed_model.encode(text)
        combined_embedding = (TEXT_WEIGHT * embedding + LAYER_WEIGHT * layer_embedding).astype('float32')
        chunk.embedding = combined_embedding # Optionally store on chunk object
        vec = np.array([combined_embedding]).astype('float32')
        self.faiss_index.add(vec)

        return chunk

    def build_bm25(self):
        if self.documents_for_bm25:
            self.bm25 = BM25Okapi(self.documents_for_bm25)
        else:
            self.bm25 = None # Or an empty BM25 object

    def update_indices(self):
        self.build_bm25()
        # FAISS is updated incrementally. If deletions are implemented, FAISS might need rebuilding or IndexIDMap.

    def get_chunk_by_bm25_faiss_internal_index(self, internal_idx):
        """Gets a chunk using its internal index from the BM25/FAISS ordered lists."""
        if 0 <= internal_idx < len(self.chunk_ids_in_bm25_faiss_order):
            chunk_id_to_fetch = self.chunk_ids_in_bm25_faiss_order[internal_idx]
            return self.chunks.get(chunk_id_to_fetch)
        return None
    
    def all_chunks(self): # For summarizer or other full traversals
        return list(self.chunks.values())

    def update_chunk_layer(self, chunk_id, new_layer): # From previous implementation
        if chunk_id in self.chunks:
            self.chunks[chunk_id].layer = new_layer
        else:
            logger.warning(f"Warning: Chunk ID {chunk_id} not found for layer update.")

